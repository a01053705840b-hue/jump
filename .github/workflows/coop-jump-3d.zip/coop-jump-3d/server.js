const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// roomCode -> { players: { mover: ws|null, jumper: ws|null }, state: {...} }
const rooms = new Map();

function makeRoomCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do {
    code = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  } while (rooms.has(code));
  return code;
}

function getOrCreateRoom(code) {
  if (!rooms.has(code)) {
    rooms.set(code, {
      players: { mover: null, jumper: null },
      map: 'easy1',
      lastState: null,
    });
  }
  return rooms.get(code);
}

function roomOf(ws) {
  return ws.roomCode ? rooms.get(ws.roomCode) : null;
}

function broadcast(room, dataObj, exceptWs = null) {
  const msg = JSON.stringify(dataObj);
  for (const role of ['mover', 'jumper']) {
    const client = room.players[role];
    if (client && client.readyState === WebSocket.OPEN && client !== exceptWs) {
      client.send(msg);
    }
  }
}

function roomStatus(room) {
  return {
    type: 'status',
    mover: !!room.players.mover,
    jumper: !!room.players.jumper,
    map: room.map,
  };
}

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.on('pong', () => (ws.isAlive = true));

  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(raw);
    } catch (e) {
      return;
    }

    if (msg.type === 'create') {
      const code = makeRoomCode();
      const room = getOrCreateRoom(code);
      const role = msg.role === 'jumper' ? 'jumper' : 'mover';
      room.players[role] = ws;
      ws.roomCode = code;
      ws.role = role;
      ws.send(JSON.stringify({ type: 'joined', role, roomCode: code }));
      broadcast(room, roomStatus(room));
      return;
    }

    if (msg.type === 'join') {
      const code = (msg.roomCode || '').toUpperCase();
      const room = rooms.get(code);
      if (!room) {
        ws.send(JSON.stringify({ type: 'error', message: '방을 찾을 수 없습니다.' }));
        return;
      }
      let role = msg.role === 'jumper' ? 'jumper' : 'mover';
      if (room.players[role]) {
        // 원하는 역할이 이미 찼으면 남은 역할 자동 배정
        const other = role === 'mover' ? 'jumper' : 'mover';
        if (!room.players[other]) {
          role = other;
        } else {
          ws.send(JSON.stringify({ type: 'error', message: '방이 가득 찼습니다.' }));
          return;
        }
      }
      room.players[role] = ws;
      ws.roomCode = code;
      ws.role = role;
      ws.send(JSON.stringify({ type: 'joined', role, roomCode: code }));
      broadcast(room, roomStatus(room));
      return;
    }

    if (msg.type === 'setMap') {
      const room = roomOf(ws);
      if (!room) return;
      room.map = msg.map;
      broadcast(room, { type: 'mapChanged', map: room.map });
      return;
    }

    if (msg.type === 'input') {
      // 이동 입력(mover) 또는 점프/대시 입력(jumper) → 상대방에게 릴레이
      const room = roomOf(ws);
      if (!room) return;
      broadcast(room, { type: 'input', role: ws.role, data: msg.data }, ws);
      return;
    }

    if (msg.type === 'state') {
      // 물리 연산을 맡은 클라이언트(보통 mover)가 전체 상태를 브로드캐스트
      const room = roomOf(ws);
      if (!room) return;
      room.lastState = msg.data;
      broadcast(room, { type: 'state', data: msg.data }, ws);
      return;
    }

    if (msg.type === 'restart') {
      const room = roomOf(ws);
      if (!room) return;
      broadcast(room, { type: 'restart' });
      return;
    }
  });

  ws.on('close', () => {
    const room = roomOf(ws);
    if (!room) return;
    if (room.players.mover === ws) room.players.mover = null;
    if (room.players.jumper === ws) room.players.jumper = null;
    broadcast(room, roomStatus(room));
    if (!room.players.mover && !room.players.jumper) {
      rooms.delete(ws.roomCode);
    }
  });
});

// 끊긴 연결 정리
setInterval(() => {
  wss.clients.forEach((ws) => {
    if (!ws.isAlive) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`서버 실행 중: http://localhost:${PORT}`);
});

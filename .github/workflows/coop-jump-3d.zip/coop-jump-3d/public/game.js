/* ==========================================================
   협동 점프맵 3D — 한 명은 이동, 한 명은 점프/대시
   ========================================================== */

// ---------- 전역 상태 ----------
let ws = null;
let myRole = null;          // 'mover' | 'jumper'
let roomCode = null;
let selectedRole = 'mover';
let selectedMapKey = 'easy1';
let connected = false;

let scene, camera, renderer, clock;
let player, playerMesh;
let platformMeshes = [];
let goalMesh;
let currentMap = null;

let startTime = null;
let finished = false;

// 물리 연산은 mover가 authoritative(권위)를 갖고 실행 후 브로드캐스트.
// jumper는 mover가 보내주는 state를 받아서 표시(간단한 신뢰 기반 동기화, 로컬망/소규모 플레이에 적합).
const isAuthoritative = () => myRole === 'mover';

// 이동 입력(로컬에서 mover가 냄, jumper는 네트워크로 받음)
const moveInput = { fwd: 0, right: 0 };
// 점프/대시 입력(로컬에서 jumper가 냄, mover는 네트워크로 받음)
const jumpInput = { jumpPressed: false, dashPressed: false, dashDir: { x: 0, z: -1 } };

const GRAVITY = -28;
const MOVE_SPEED = 7.5;
const JUMP_VELOCITY = 11;
const DASH_SPEED = 22;
const DASH_DURATION = 0.18;
const DASH_COOLDOWN = 1.0;
let dashCooldownTimer = 0;
let dashTimer = 0;
let dashVec = new THREE.Vector3();

const playerState = {
  pos: new THREE.Vector3(0, 2, 0),
  vel: new THREE.Vector3(0, 0, 0),
  onGround: false,
  radius: 0.5,
};

// ---------- 로비 UI ----------
function buildMapGrid() {
  const grid = document.getElementById('map-grid');
  grid.innerHTML = '';
  MAP_ORDER.forEach((key) => {
    const m = MAPS[key];
    const div = document.createElement('div');
    div.className = 'map-card' + (key === selectedMapKey ? ' active' : '');
    div.dataset.key = key;
    div.innerHTML = `<span class="diff diff-${m.difficulty}">${m.diffLabel}</span><br>${m.name}`;
    div.addEventListener('click', () => {
      selectedMapKey = key;
      document.querySelectorAll('.map-card').forEach((c) => c.classList.remove('active'));
      div.classList.add('active');
      if (ws && connected) {
        ws.send(JSON.stringify({ type: 'setMap', map: selectedMapKey }));
      }
    });
    grid.appendChild(div);
  });
}
buildMapGrid();

document.querySelectorAll('.role-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.role-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    selectedRole = btn.dataset.role;
  });
});

function setLobbyStatus(text) {
  document.getElementById('lobby-status').textContent = text;
}

function connectWS() {
  const proto = location.protocol === 'https:' ? 'wss://' : 'ws://';
  ws = new WebSocket(proto + location.host);

  ws.onopen = () => {
    connected = true;
  };

  ws.onclose = () => {
    connected = false;
    updateConnBadge(false);
  };

  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    handleServerMessage(msg);
  };
}

function handleServerMessage(msg) {
  switch (msg.type) {
    case 'joined': {
      myRole = msg.role;
      roomCode = msg.roomCode;
      document.getElementById('room-code-display').style.display = 'block';
      document.getElementById('room-code-display').innerHTML =
        `방 코드 <b>${roomCode}</b> — 친구에게 공유하세요!`;
      setLobbyStatus(`역할: ${myRole === 'mover' ? '이동 담당 🕹' : '점프 담당 🚀'} · 상대 접속 대기 중...`);
      break;
    }
    case 'status': {
      const bothIn = msg.mover && msg.jumper;
      if (bothIn) {
        setLobbyStatus('둘 다 접속 완료! 게임을 시작합니다...');
        setTimeout(() => startGame(msg.map), 500);
      } else {
        const waiting = msg.mover ? '점프 담당' : '이동 담당';
        setLobbyStatus(`${waiting} 플레이어를 기다리는 중...`);
      }
      break;
    }
    case 'mapChanged': {
      selectedMapKey = msg.map;
      if (currentMap) {
        loadMap(selectedMapKey);
      }
      break;
    }
    case 'error': {
      setLobbyStatus('⚠ ' + msg.message);
      break;
    }
    case 'input': {
      if (msg.role === 'mover') {
        // 상대가 mover: 이동 입력 수신
        moveInput.fwd = msg.data.fwd;
        moveInput.right = msg.data.right;
      } else if (msg.role === 'jumper') {
        jumpInput.jumpPressed = msg.data.jumpPressed;
        jumpInput.dashPressed = msg.data.dashPressed;
        jumpInput.dashDir = msg.data.dashDir;
      }
      break;
    }
    case 'state': {
      if (!isAuthoritative()) {
        // jumper는 mover가 계산한 상태를 그대로 반영
        playerState.pos.set(msg.data.x, msg.data.y, msg.data.z);
        playerState.onGround = msg.data.onGround;
        if (msg.data.finished) onGoalReached(false);
        if (msg.data.elapsed !== undefined) updateTimerDisplay(msg.data.elapsed);
      }
      break;
    }
    case 'restart': {
      resetPlayer();
      break;
    }
  }
}

function updateConnBadge(ok) {
  const badge = document.getElementById('conn-badge');
  const text = document.getElementById('conn-text');
  badge.classList.toggle('ok', ok);
  text.textContent = ok ? '연결됨' : '연결 끊김';
}

document.getElementById('create-btn').addEventListener('click', () => {
  if (!ws) connectWS();
  const send = () => ws.send(JSON.stringify({ type: 'create', role: selectedRole }));
  if (ws.readyState === WebSocket.OPEN) send();
  else ws.addEventListener('open', send, { once: true });
  setLobbyStatus('방 생성 중...');
});

document.getElementById('join-btn').addEventListener('click', () => {
  const code = document.getElementById('room-code-input').value.trim().toUpperCase();
  if (!code) {
    setLobbyStatus('⚠ 방 코드를 입력하세요.');
    return;
  }
  if (!ws) connectWS();
  const send = () => ws.send(JSON.stringify({ type: 'join', role: selectedRole, roomCode: code }));
  if (ws.readyState === WebSocket.OPEN) send();
  else ws.addEventListener('open', send, { once: true });
  setLobbyStatus('참가 중...');
});

// ---------- 게임 시작 / Three.js 초기화 ----------
function startGame(mapKey) {
  document.getElementById('lobby').style.display = 'none';
  document.getElementById('hud').classList.add('show');
  document.getElementById('conn-badge').classList.add('show');
  updateConnBadge(true);

  const roleBadge = document.getElementById('role-badge');
  roleBadge.textContent = myRole === 'mover' ? '🕹 이동 담당' : '🚀 점프 담당';
  roleBadge.classList.add(myRole);

  const hint = document.getElementById('controls-hint');
  if (myRole === 'mover') {
    hint.innerHTML = '<b>이동 담당</b><br>WASD / 방향키: 이동<br>점프·대시는 파트너가 맡습니다.';
  } else {
    hint.innerHTML = '<b>점프 담당</b><br>스페이스: 점프<br>Shift: 대시<br>이동은 파트너가 맡습니다.';
  }

  if (isTouchDevice()) {
    document.getElementById('touch-controls').classList.add('show');
    setupTouchControls();
  }

  if (!renderer) initThree();
  loadMap(mapKey || selectedMapKey);
  resetPlayer();
  animate();
}

function isTouchDevice() {
  return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
}

function initThree() {
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 500);

  renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('game-canvas'), antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;

  const ambient = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambient);

  const sun = new THREE.DirectionalLight(0xffffff, 0.9);
  sun.position.set(20, 40, 10);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -60;
  sun.shadow.camera.right = 60;
  sun.shadow.camera.top = 60;
  sun.shadow.camera.bottom = -60;
  sun.shadow.camera.far = 200;
  scene.add(sun);

  playerMesh = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.5, 1.0, 4, 8),
    new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0x222222 })
  );
  playerMesh.castShadow = true;
  scene.add(playerMesh);

  clock = new THREE.Clock();

  window.addEventListener('resize', onWindowResize);
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);

  document.getElementById('restart-btn').addEventListener('click', () => {
    if (ws) ws.send(JSON.stringify({ type: 'restart' }));
    resetPlayer();
  });
}

function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function loadMap(key) {
  currentMap = MAPS[key];
  selectedMapKey = key;

  // 기존 플랫폼 제거
  platformMeshes.forEach((p) => scene.remove(p.mesh));
  platformMeshes = [];
  if (goalMesh) scene.remove(goalMesh);

  scene.background = new THREE.Color(currentMap.skyColor);
  scene.fog = new THREE.Fog(currentMap.fogColor, 20, 140);

  currentMap.platforms.forEach((p) => {
    const geo = new THREE.BoxGeometry(p.sx, p.sy, p.sz);
    const mat = new THREE.MeshStandardMaterial({ color: p.color, roughness: 0.7 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(p.x, p.y, p.z);
    mesh.receiveShadow = true;
    mesh.castShadow = true;
    scene.add(mesh);
    platformMeshes.push({ mesh, def: p, basePos: { x: p.x, y: p.y, z: p.z } });
  });

  const goalGeo = new THREE.ConeGeometry(1.2, 2.4, 16);
  const goalMat = new THREE.MeshStandardMaterial({ color: 0xffe082, emissive: 0x664400, emissiveIntensity: 0.4 });
  goalMesh = new THREE.Mesh(goalGeo, goalMat);
  goalMesh.position.set(currentMap.goal.x, currentMap.goal.y + 2.5, currentMap.goal.z);
  scene.add(goalMesh);
}

function resetPlayer() {
  finished = false;
  startTime = performance.now();
  playerState.pos.set(currentMap.start.x, currentMap.start.y, currentMap.start.z);
  playerState.vel.set(0, 0, 0);
  playerState.onGround = false;
  dashCooldownTimer = 0;
  dashTimer = 0;
  document.getElementById('center-msg').innerHTML = '';
  document.getElementById('restart-btn').classList.remove('show');
}

// ---------- 입력 ----------
const keys = {};
function onKeyDown(e) {
  keys[e.code] = true;
  if (myRole === 'jumper') {
    if (e.code === 'Space') jumpInput.jumpPressed = true;
    if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') jumpInput.dashPressed = true;
  }
}
function onKeyUp(e) {
  keys[e.code] = false;
}

function readMoveKeys() {
  let fwd = 0, right = 0;
  if (keys['KeyW'] || keys['ArrowUp']) fwd += 1;
  if (keys['KeyS'] || keys['ArrowDown']) fwd -= 1;
  if (keys['KeyD'] || keys['ArrowRight']) right += 1;
  if (keys['KeyA'] || keys['ArrowLeft']) right -= 1;
  return { fwd, right };
}

// ---------- 터치 컨트롤 ----------
function setupTouchControls() {
  const zone = document.getElementById('stick-zone');
  const knob = document.getElementById('stick-knob');
  let touchId = null;
  let center = { x: 0, y: 0 };

  function start(e) {
    const t = e.changedTouches[0];
    touchId = t.identifier;
    const rect = zone.getBoundingClientRect();
    center = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  }
  function move(e) {
    for (const t of e.changedTouches) {
      if (t.identifier !== touchId) continue;
      let dx = t.clientX - center.x;
      let dy = t.clientY - center.y;
      const max = 45;
      const dist = Math.min(Math.hypot(dx, dy), max);
      const angle = Math.atan2(dy, dx);
      dx = Math.cos(angle) * dist;
      dy = Math.sin(angle) * dist;
      knob.style.left = 37 + dx + 'px';
      knob.style.top = 37 + dy + 'px';
      moveInput.right = dx / max;
      moveInput.fwd = -dy / max;
    }
  }
  function end(e) {
    for (const t of e.changedTouches) {
      if (t.identifier !== touchId) continue;
      touchId = null;
      knob.style.left = '37px';
      knob.style.top = '37px';
      moveInput.fwd = 0;
      moveInput.right = 0;
    }
  }
  zone.addEventListener('touchstart', start, { passive: true });
  zone.addEventListener('touchmove', move, { passive: true });
  zone.addEventListener('touchend', end, { passive: true });
  zone.addEventListener('touchcancel', end, { passive: true });

  document.getElementById('jump-btn').addEventListener('touchstart', (e) => {
    e.preventDefault();
    jumpInput.jumpPressed = true;
  }, { passive: false });

  document.getElementById('dash-btn').addEventListener('touchstart', (e) => {
    e.preventDefault();
    jumpInput.dashPressed = true;
  }, { passive: false });
}

// ---------- 물리 & 게임 루프 ----------
function updateMovingPlatforms(t) {
  platformMeshes.forEach((p) => {
    if (!p.def.moving) return;
    const speed = p.def.speed || 1;
    const offset = Math.sin(t * speed);
    let nx = p.basePos.x, ny = p.basePos.y, nz = p.basePos.z;
    if (p.def.mx) nx += offset * p.def.mx;
    if (p.def.my) ny += offset * p.def.my;
    if (p.def.mz) nz += offset * p.def.mz;
    p.mesh.position.set(nx, ny, nz);
  });
}

function checkPlatformCollision(dt) {
  const r = playerState.radius;
  let grounded = false;
  const pos = playerState.pos;

  for (const p of platformMeshes) {
    const box = p.mesh.position;
    const half = { x: p.def.sx / 2, y: p.def.sy / 2, z: p.def.sz / 2 };

    const withinX = pos.x + r > box.x - half.x && pos.x - r < box.x + half.x;
    const withinZ = pos.z + r > box.z - half.z && pos.z - r < box.z + half.z;
    const topY = box.y + half.y;

    if (withinX && withinZ) {
      // 착지 판정: 발밑이 플랫폼 상단 근처이고 하강 중
      if (playerState.vel.y <= 0 && pos.y - r <= topY && pos.y - r >= topY - 0.6) {
        pos.y = topY + r;
        playerState.vel.y = 0;
        grounded = true;
      }
    }
  }
  playerState.onGround = grounded;
}

function updatePhysics(dt, elapsedTime) {
  // 이동 입력 적용 (mover가 낸 입력을 양쪽 모두 사용)
  const camAngle = 0; // 카메라가 항상 -Z를 바라보는 3인칭 추적이라 별도 회전 불필요
  const dir = new THREE.Vector3(moveInput.right, 0, -moveInput.fwd);
  if (dir.lengthSq() > 0) dir.normalize();

  if (dashTimer > 0) {
    // 대시 중: 대시 벡터로 강제 이동
    playerState.pos.addScaledVector(dashVec, dt);
    dashTimer -= dt;
  } else {
    playerState.vel.x = dir.x * MOVE_SPEED;
    playerState.vel.z = dir.z * MOVE_SPEED;
    playerState.pos.x += playerState.vel.x * dt;
    playerState.pos.z += playerState.vel.z * dt;
  }

  // 점프 처리
  if (jumpInput.jumpPressed) {
    if (playerState.onGround) {
      playerState.vel.y = JUMP_VELOCITY;
      playerState.onGround = false;
    }
    jumpInput.jumpPressed = false;
  }

  // 대시 처리
  if (dashCooldownTimer > 0) dashCooldownTimer -= dt;
  if (jumpInput.dashPressed) {
    if (dashCooldownTimer <= 0 && dashTimer <= 0) {
      let dx = moveInput.right, dz = -moveInput.fwd;
      if (dx === 0 && dz === 0) dz = -1; // 입력 없으면 전방 대시
      const len = Math.hypot(dx, dz) || 1;
      dashVec.set((dx / len) * DASH_SPEED, 0, (dz / len) * DASH_SPEED);
      dashTimer = DASH_DURATION;
      dashCooldownTimer = DASH_COOLDOWN;
    }
    jumpInput.dashPressed = false;
  }

  // 중력
  if (!playerState.onGround) {
    playerState.vel.y += GRAVITY * dt;
  }
  playerState.pos.y += playerState.vel.y * dt;

  checkPlatformCollision(dt);

  // 낙사 → 리스폰
  if (playerState.pos.y < -20) {
    playerState.pos.set(currentMap.start.x, currentMap.start.y, currentMap.start.z);
    playerState.vel.set(0, 0, 0);
  }

  // 골 판정
  if (!finished) {
    const gx = currentMap.goal.x - playerState.pos.x;
    const gy = currentMap.goal.y - playerState.pos.y;
    const gz = currentMap.goal.z - playerState.pos.z;
    const dist = Math.sqrt(gx * gx + gy * gy + gz * gz);
    if (dist < (currentMap.goal.r || 1.5) + 1.2) {
      onGoalReached(true);
    }
  }
}

function onGoalReached(broadcastIt) {
  if (finished) return;
  finished = true;
  const elapsed = (performance.now() - startTime) / 1000;
  document.getElementById('center-msg').innerHTML =
    `<h2>🎉 클리어! ${elapsed.toFixed(2)}초</h2><p>정말 잘했어요! 다음 난이도에 도전해보세요.</p>`;
  document.getElementById('restart-btn').classList.add('show');
  if (broadcastIt && ws) {
    ws.send(JSON.stringify({
      type: 'state',
      data: { x: playerState.pos.x, y: playerState.pos.y, z: playerState.pos.z, onGround: playerState.onGround, finished: true, elapsed },
    }));
  }
}

function updateTimerDisplay(elapsedOverride) {
  const el = document.getElementById('timer-badge');
  const elapsed = elapsedOverride !== undefined ? elapsedOverride : (startTime ? (performance.now() - startTime) / 1000 : 0);
  const m = Math.floor(elapsed / 60).toString().padStart(2, '0');
  const s = (elapsed % 60).toFixed(2).padStart(5, '0');
  el.textContent = `${m}:${s}`;
}

// ---------- 입력 송신 (네트워크) ----------
let lastSendTime = 0;
function sendInputsAndState(t) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  if (t - lastSendTime < 1000 / 30) return; // 30Hz
  lastSendTime = t;

  if (myRole === 'mover') {
    const m = readMoveKeys();
    if (m.fwd !== moveInput.fwd || m.right !== moveInput.right) {
      moveInput.fwd = m.fwd;
      moveInput.right = m.right;
    }
    ws.send(JSON.stringify({ type: 'input', data: { fwd: moveInput.fwd, right: moveInput.right } }));
  }

  if (isAuthoritative()) {
    ws.send(JSON.stringify({
      type: 'state',
      data: {
        x: playerState.pos.x, y: playerState.pos.y, z: playerState.pos.z,
        onGround: playerState.onGround,
        finished,
        elapsed: startTime ? (performance.now() - startTime) / 1000 : 0,
      },
    }));
  }

  if (myRole === 'jumper') {
    // dashDir은 이동 입력을 참고해 방향을 계산하지만 실제 입력은 로컬 press로만 트리거
  }
}

// jumper 쪽 대시/점프 입력을 상대(mover)에게 전달
function sendJumperInputIfNeeded() {
  if (myRole !== 'jumper' || !ws || ws.readyState !== WebSocket.OPEN) return;
  if (jumpInput.jumpPressed || jumpInput.dashPressed) {
    ws.send(JSON.stringify({
      type: 'input',
      data: {
        jumpPressed: jumpInput.jumpPressed,
        dashPressed: jumpInput.dashPressed,
        dashDir: jumpInput.dashDir,
      },
    }));
  }
}

// ---------- 렌더 루프 ----------
function updateCamera() {
  const p = playerState.pos;
  const camOffset = new THREE.Vector3(0, 4.5, 9);
  camera.position.set(p.x + camOffset.x * 0.15, p.y + camOffset.y, p.z + camOffset.z);
  camera.lookAt(p.x, p.y + 1, p.z);
}

function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = clock.getElapsedTime();

  updateMovingPlatforms(t);

  if (isAuthoritative()) {
    updatePhysics(dt, t);
  }

  playerMesh.position.copy(playerState.pos);
  updateCamera();
  updateTimerDisplay();

  sendInputsAndState(performance.now());
  sendJumperInputIfNeeded();
  // 전송 후 로컬에서도 즉시 리셋해 중복 전송 방지(다음 프레임에서 다시 눌리면 재전송)
  if (myRole === 'jumper') {
    jumpInput.jumpPressed = false;
    jumpInput.dashPressed = false;
  }

  renderer.render(scene, camera);
}
